from . import CognitoApi, IamApi, RekognitionApi, S3Api, LineApi
from . import agentConfig
import json


class MemberRegisterController:
    def __init__(self):
        self.__agent = agentConfig.agent
        self.__cognitoApi = CognitoApi.CognitoApi()
        self.__iamApi = IamApi.IamApi()
        self.__rekognitionApi = RekognitionApi.RekognitionApi()
        self.__s3Api = S3Api.S3Api()
        self.__lineApi = LineApi.LineApi()
    
    def signUp(self, viewData):
        daoData = {
            'metaData': {
                'agent': self.__agent
            },
            'userData': viewData
        }
        
        result = self.__cognitoApi.signUpUser(daoData)

        return result
    
    def confirm(self, viewData):
        daoData = {
            'metaData': {
                'agent': self.__agent
            },
            'userData': viewData
        }

        result = self.__cognitoApi.confirmUserEmail(daoData)
        
        if result['statusCode'] == 200:
            self.__cognitoApi.addToAgentGroup(daoData)
            self.__iamApi.createIamUser(daoData)
            self.__iamApi.addToRoleGroup(daoData)
        
        elif result['statusCode'] == 500:
            self.__cognitoApi.deleteUser(daoData)
        
        return result
    
    def fido(self, viewData):
        daoData = {
            'userData': viewData
        }

        attributesUpdateList = ['custom:publicKeyCred']
        result = self.__cognitoApi.updateUserAttributes(daoData, attributesUpdateList)
        return result
    
    def face(self, viewData):
        daoData = {
            'userData': viewData
        }

        attributesRetrieveList = ['sub']
        retrieveResult = self.__cognitoApi.retrieveUsers(daoData, 'username', attributesRetrieveList)
        daoData['id'] = {'sub': retrieveResult['body']['Users'][0]['Attributes'][0]['Value']}
    
        indexsFaceResult = self.__rekognitionApi.addToFaceCollection(daoData)
        daoData['id']['custom:faceId'] = indexsFaceResult['body']['FaceRecords'][0]['Face']['FaceId']
        
        self.__s3Api.storeImage(daoData)
        attributesUpdateList = ['custom:faceId', 'picture']
        result = self.__cognitoApi.updateUserAttributes(daoData, attributesUpdateList)
        
        return result
    
    def line(self, viewData):
        verifyResult = self.__lineApi.verifySignature(viewData)
        
        if verifyResult['statusCode'] == 200:
            viewData['body'] = json.loads(viewData['body'])
            
            for event in viewData['body']['events']:
                if event['type'] == 'memberJoined':
                    daoData = {
                        'id':{'custom:lineId':event['joined']['members'][0]['userId']}
                    }

                    getResult = self.__lineApi.getUserProfile(daoData)
                    daoData = getResult['body']
                    
                    attributesRetrieveList = []
                    retrieveResult = self.__cognitoApi.retrieveUsers(daoData, 'name', attributesRetrieveList)
                    daoData['userData']['username'] = retrieveResult['body']['Users'][0]['Username']
                    
                    attributesUpdateList = ['custom:lineId']
                    self.__cognitoApi.updateUserAttributes(daoData, attributesUpdateList)
                    break
                    
        return  verifyResult
        