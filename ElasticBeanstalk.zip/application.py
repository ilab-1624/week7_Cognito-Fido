from flask import Flask, render_template, session, request, redirect, url_for, jsonify, Response
from module import MemberRegisterController, ConfigController, CognitoApi
from module import agentConfig, fidoServerConfig
import json


application = Flask(__name__)


agent = agentConfig.agent
fidoServerUrl = fidoServerConfig.fidoServerUrl


# ========================== ↓↓↓↓ View ↓↓↓↓ ====================================

# ------------------------- ↓↓ home page ↓↓ ------------------------------------

@application.route("/", methods = ['GET'])
def getMenu():
    if request.method == 'GET':
        return render_template('amsMenu.html' , agent=agent)

# ------------------------ ↓↓ memberRegister ↓↓ --------------------------------

@application.route("/memberRegister", methods = ['GET', 'POST'])
def memberRegister():
    if request.method == 'GET':
        return render_template('memberRegisterRequest.html', agent=agent, fidoServerUrl=fidoServerUrl)
    
    if request.method == 'POST':
        daoModel = {
            'userData':{
                'username': request.values['username']
            }
        }

        attributesRetrieveList = [
            'sub',
            'custom:lineId',
            'custom:faceId'
        ]
        cognitoApi = CognitoApi.CognitoApi()
        retrieveResult = cognitoApi.retrieveUsers(daoModel, 'username', attributesRetrieveList)
        
        userModel = {
            'username': request.values['username'],
            'sub': retrieveResult['body']['Users'][0]['Attributes'][0]['Value'],
            'email': request.values['email'],
            'name': request.values['lineNickname'],
            'custom:lineId': retrieveResult['body']['Users'][0]['Attributes'][1]['Value'],
            'custom:faceId': retrieveResult['body']['Users'][0]['Attributes'][2]['Value'],
            'agent': agent
        }
        
        if request.values['role'] == 'customer':
            userModel['ch_role'] = '成員'
        elif request.values['role'] == 'staff':
            userModel['ch_role'] = '工程師'
        else:
            userModel['ch_role'] = '管理員'
        
        return render_template('memberRegisterResponse.html', userModel=userModel)

# --------------------------- ↓↓ config ↓↓ -------------------------------------

configController = ConfigController.ConfigController()
@application.route("/config",methods = ['GET'])
def getConfigMenu():
    if request.method == 'GET':
        return render_template('configMenu.html' , agent = agent)


@application.route("/config/objectDetect/update",methods = ['GET'])
def getConfigObject():
    if request.method == 'GET':
        aiConfigData = configController.retrieveAiConfig('objectDetection')
        return render_template('configObject.html', aiConfig = aiConfigData)

@application.route("/config/memberRecognition/update",methods = ['GET'])
def getConfigFace():
    if request.method == 'GET':
        aiConfigData = configController.retrieveAiConfig('faceRecognition')
        return render_template('configFace.html', aiConfig = aiConfigData)

@application.route("/config/ppeDetect/update",methods = ['GET'])
def getConfigPpe():
    if request.method == 'GET':
        aiConfigData = configController.retrieveAiConfig('ppeValidation')
        return render_template('configPpe.html', aiConfig = aiConfigData)

@application.route("/config/fraudDetect/update",methods = ['GET'])
def getConfigAnomaly():
    if request.method == 'GET':
        aiConfigData = configController.retrieveAiConfig('anomalyDetection')
        return render_template('configAnomaly.html', aiConfig = aiConfigData)

@application.route("/config/forecast/update",methods = ['GET'])
def getConfigForecast():
    if request.method == 'GET':
        aiConfigData = configController.retrieveAiConfig('forecast')
        return render_template('configForecast.html', aiConfig = aiConfigData)

# ======================= ↓↓↓↓ Controller ↓↓↓↓ ==================================

# --------------------------- ↓↓ config ↓↓ --------------------------------------

@application.route("/updateAiConfig",methods = ['POST'])
def updateAiConfig():
    aiConfigData = json.loads(request.get_data())
    configController.updateAiConfig(aiConfigData)

    return jsonify('ok')

# ------------------------ ↓↓ memberRegister ↓↓ ----------------------------------

memberRegisterController = MemberRegisterController.MemberRegisterController()
@application.route("/register/signUp", methods = ['POST'])
def signUp():
    userData = json.loads(request.get_data())
    result = memberRegisterController.signUp(userData)

    return jsonify(result)

@application.route("/register/confirm", methods = ['POST'])
def confirm():
    userData = json.loads(request.get_data())
    result = memberRegisterController.confirm(userData)

    return jsonify(result)

@application.route("/fido", methods = ['POST'])
def fido():
    viewData = json.loads(request.get_data())
    result = memberRegisterController.fido(viewData)

    return jsonify(result)

@application.route("/face", methods = ['POST'])
def face():
    viewData = json.loads(request.get_data())
    result = memberRegisterController.face(viewData)
    
    return jsonify(result)

@application.route("/line", methods = ['POST'])
def line():
    viewData = {
        'body': request.get_data(as_text=True),
        'signature': request.headers['X-Line-Signature']
    }
    result = memberRegisterController.line(viewData)
    
    return jsonify(result)

    
if __name__ == '__main__':
    application.config['TEMPLATES_AUTO_RELOAD'] = True      
    application.jinja_env.auto_reload = True
    application.run(debug=True)